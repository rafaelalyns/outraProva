package Tasks;

import org.openqa.selenium.WebDriver;

import Framework.Utils.FileOperation;
import PageObjects.LoginPage;
import Validations.LoginValidation;

public class LoginTask {
    
private WebDriver driver;
private LoginPage loginPage;
private LoginValidation loginValidation;
    
    public LoginTask(WebDriver driver) {
        
        this.driver= driver;
        loginPage = new LoginPage(this.driver);
        loginValidation = new LoginValidation(this.driver);
    }
    
    public void efetuarLogin() {
        
        loginValidation.validationLoginPage();
        loginPage.getEmailInput().sendKeys("rafaelapereira@teste.com.br");
        loginPage.getPasswordInput().sendKeys("testeteste");
        loginPage.getEnterButton().click();
    }
    
   public void efetuarLoginParametrizado(String user, String password) {
        
        loginValidation.validationLoginPage();
        loginPage.getEmailInput().sendKeys(user);
        loginPage.getPasswordInput().sendKeys(password);
        loginPage.getEnterButton().click();
    }
   
   public void efetuarLoginProperties() {
       
       loginValidation.validationLoginPage();
       loginPage.getEmailInput().sendKeys(FileOperation.getProperties("user").getProperty("user"));
       loginPage.getPasswordInput().sendKeys(FileOperation.getProperties("user").getProperty("password"));
       loginPage.getEnterButton().click();
   }


}
