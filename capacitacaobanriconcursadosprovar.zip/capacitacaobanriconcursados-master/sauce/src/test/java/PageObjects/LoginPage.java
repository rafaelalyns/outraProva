package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    
    private WebDriver driver;
    
    public LoginPage(WebDriver driver) {
        
        this.driver = driver;        
    }
    
    public WebElement getLogoText() {
        
        /*WebElement logoText  = driver.findElement(By.className("login_logo"));
        return logoText;*/
        
        return driver.findElement(By.className("navbar-brand"));
    }
    
    public WebElement getEmailInput() {
        
        return driver.findElement(By.id("email"));
    }
    
    public WebElement getPasswordInput() {
        
        return driver.findElement(By.id("senha"));
    }
    
    public WebElement getEnterButton() {
        
        return driver.findElement(By.className("btn btn-primary"));
        
    }

}
