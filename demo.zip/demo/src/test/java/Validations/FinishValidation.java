package Validations;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import Report.Report;
import Report.Screenshot;
import pageObjects.ContasPage;
import pageObjects.FinishPage;

public class FinishValidation {
private WebDriver driver;
    
    public FinishValidation(WebDriver driver) {
        this.driver = driver;
        FinishPage finishPage = new FinishPage(this.driver);
    }
public void validationFinishPage() {
        
        try {
            FinishPage finishPage = null;
            Assertions.assertTrue(finishPage.getLogoText().isDisplayed());
            Report.log(Status.PASS, "Acessou a p�gina de Login corretamente", Screenshot.captureBase64(driver));
            
        }catch (Exception e) {
            
            Report.log(Status.FAIL, e.getMessage(), Screenshot.captureBase64(driver));
        }
}
}
