package Tasks;

import org.openqa.selenium.WebDriver;

import Validations.FinishValidation;
import pageObjects.FinishPage;

public class FinishTask {
    private WebDriver driver;
    FinishPage finishPage = new FinishPage(this.driver);
    FinishValidation finishValidation = new FinishValidation(this.driver);
    
}
